@ECHO OFF
COLOR 9F
FOR /F "tokens=*" %%G IN ('DIR /B /A "*.pwn"') DO (
	ECHO Building %%G
	..\pawno\pawncc.exe -i..\\include %%G  -(+ -;+ -r
)
ECHO Sequence completed!
pause
GOTO :eof

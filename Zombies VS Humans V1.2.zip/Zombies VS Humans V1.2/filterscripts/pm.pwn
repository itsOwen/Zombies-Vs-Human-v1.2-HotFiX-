// pm

#include <a_samp>
#include <gl_common>

#define GREEN 0x21DD00FF
#define red 0xFF0000AA
#define PURPLE 0xB360FDFF


public OnPlayerCommandText(playerid, cmdtext[])
{
	new cmd[256];
	new	tmp[256];
	new Message[256];
	new gMessage[256];
	new pName[MAX_PLAYER_NAME+1];
	new iName[MAX_PLAYER_NAME+1];
	new	idx;

	cmd = strtok(cmdtext, idx);


	if(strcmp("/pm", cmd, true) == 0)
	{
		tmp = strtok(cmdtext,idx);

		if(!strlen(tmp) || strlen(tmp) > 5) {
			SendClientMessage(playerid,GREEN,"Use /pm [id] [text]");
			return 1;
		}

		new id = strval(tmp);
        gMessage = strrest(cmdtext,idx);

		if(!strlen(gMessage)) {
			SendClientMessage(playerid,GREEN,"Use /pm [id] [text]");
			return 1;
		}

		if(!IsPlayerConnected(id)) {
			SendClientMessage(playerid,red,"Server: Player ID not found, please check the ID and try again.");
			return 1;
		}

		if(playerid != id) {
			GetPlayerName(id,iName,sizeof(iName));
			GetPlayerName(playerid,pName,sizeof(pName));
			format(Message,sizeof(Message),"PM Sent to %s (ID: %d): %s",iName,id,gMessage);
			SendClientMessage(playerid,0xFFFF00AA,Message);
			format(Message,sizeof(Message),"PM From %s (ID: %d): %s",pName,playerid,gMessage);
			SendClientMessage(id,0xFFFF00AA,Message);
			PlayerPlaySound(id,1085,0.0,0.0,0.0);

			printf("PM Logger: %s (ID:%s) (Name: %s)",Message, playerid, pName);

		}
		else {
			SendClientMessage(playerid,PURPLE,"Server: You cannot send a personal message to yourself!");
		}
		return 1;
	}
	return 0;
}

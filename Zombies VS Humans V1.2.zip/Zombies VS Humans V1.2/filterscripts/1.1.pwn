#include <a_samp>
new Text:td_fuel[MAX_PLAYERS];
new Text:td_vhealth[MAX_PLAYERS];
new Text:td_vspeed[MAX_PLAYERS];
new Text:td_box[MAX_PLAYERS];

forward timer_update();
forward timer_refuel(playerid);
new isrefuelling[MAX_PLAYERS] = 0;
new fuel[MAX_VEHICLES];
new Float:max_vhealth[MAX_VEHICLES];
new Engine[MAX_PLAYERS];

public OnFilterScriptInit()
{
    for(new i=0;i<MAX_VEHICLES;i++) {
        GetVehicleHealth(i,max_vhealth[i]); //getting max health
        fuel[i] = 250 + random(150);  //setting fuel for vehicles
    }
    for(new i=0;i<MAX_PLAYERS;i++) { //setting up all textdraws
        td_fuel[i] = TextDrawCreate(476,355,"Fuel:");
        td_vhealth[i] = TextDrawCreate(478,376,"Health:");
        td_vspeed[i] = TextDrawCreate(478,397,"Speed:");
        td_box[i] = TextDrawCreate(478.000000,328.000000,"Vehicle Stats: ~n~~n~~n~~n~");
        TextDrawUseBox(td_box[i],1);
        TextDrawBoxColor(td_box[i],0x00000066);
        TextDrawTextSize(td_box[i],626.000000,21.000000);
        TextDrawAlignment(td_fuel[i],0);
        TextDrawAlignment(td_vhealth[i],0);
        TextDrawAlignment(td_vspeed[i],0);
        TextDrawAlignment(td_box[i],0);
        TextDrawBackgroundColor(td_fuel[i],0x000000ff);
        TextDrawBackgroundColor(td_vhealth[i],0x000000ff);
        TextDrawBackgroundColor(td_vspeed[i],0x000000ff);
        TextDrawBackgroundColor(td_box[i],0x000000cc);
        TextDrawFont(td_fuel[i],1);
        TextDrawLetterSize(td_fuel[i],0.699999,2.699999);
        TextDrawFont(td_vhealth[i],1);
        TextDrawLetterSize(td_vhealth[i],0.699999,2.699999);
        TextDrawFont(td_vspeed[i],1);
        TextDrawLetterSize(td_vspeed[i],0.699999,2.699999);
        TextDrawFont(td_box[i],0);
        TextDrawLetterSize(td_box[i],0.699999,2.899999);
        TextDrawColor(td_fuel[i],0xffffffff);
        TextDrawColor(td_vhealth[i],0xffffffff);
        TextDrawColor(td_vspeed[i],0xffffffff);
        TextDrawColor(td_box[i],0xffffffff);
        TextDrawSetOutline(td_fuel[i],1);
        TextDrawSetOutline(td_vhealth[i],1);
        TextDrawSetOutline(td_vspeed[i],1);
        TextDrawSetOutline(td_box[i],1);
        TextDrawSetProportional(td_fuel[i],1);
        TextDrawSetProportional(td_vhealth[i],1);
        TextDrawSetProportional(td_vspeed[i],1);
        TextDrawSetProportional(td_box[i],1);
        TextDrawSetShadow(td_fuel[i],1);
        TextDrawSetShadow(td_vhealth[i],1);
        TextDrawSetShadow(td_vspeed[i],1);
        TextDrawSetShadow(td_box[i],10);
    }
    SetTimer("timer_update",1000,true);
    return 1;
}

public OnFilterScriptExit()
{
    for(new i=0;i<MAX_PLAYERS;i++) {
        TextDrawDestroy(td_fuel[i]);
        TextDrawDestroy(td_vhealth[i]);
        TextDrawDestroy(td_vspeed[i]);
        TextDrawDestroy(td_box[i]);
    }
    return 1;
}

public OnPlayerStateChange(playerid, newstate, oldstate)
{
    if (newstate == PLAYER_STATE_DRIVER || newstate == PLAYER_STATE_PASSENGER)
    {
    	if(IsPlayerNPC(playerid)) return 1;

        TextDrawSetString(td_fuel[playerid],"Fuel:");
        TextDrawSetString(td_vhealth[playerid],"Health:");
        TextDrawSetString(td_vspeed[playerid],"Speed:");

        TextDrawShowForPlayer(playerid,td_fuel[playerid]);
        TextDrawShowForPlayer(playerid,td_vspeed[playerid]);
        TextDrawShowForPlayer(playerid,td_vhealth[playerid]);
        TextDrawShowForPlayer(playerid,td_box[playerid]);
    } else {
        TextDrawHideForPlayer(playerid,td_fuel[playerid]);
        TextDrawHideForPlayer(playerid,td_vspeed[playerid]);
        TextDrawHideForPlayer(playerid,td_vhealth[playerid]);
        TextDrawHideForPlayer(playerid,td_box[playerid]);
    }
    return 1;
}

public timer_update()
{
    for(new i=0;i<MAX_PLAYERS;i++) {
        if (isrefuelling[i]) return 0;
        new vid = GetPlayerVehicleID(i);
        if (GetPlayerVehicleSeat(i) == 0) {
            fuel[vid] = fuel[vid] - 1;
            if (fuel[vid]<1)
            {
                fuel[vid] = 0;
                new veh = GetPlayerVehicleID(i);
                new engine,lights,alarm,doors,bonnet,boot,objective;
                GetVehicleParamsEx(veh,engine,lights,alarm,doors,bonnet,boot,objective);
                SetVehicleParamsEx(veh,VEHICLE_PARAMS_OFF,lights,alarm,doors,bonnet,boot,objective);
                Engine[i]=0;
                GameTextForPlayer(i,"~r~You are out of ~w~fuel~r~!",5000,4);
            }
        }
        new string[128];format(string,sizeof string,"Fuel:    %i",fuel[vid] /3);
        TextDrawSetString(td_fuel[i],string);

        new Float:speed_x,Float:speed_y,Float:speed_z,Float:temp_speed,final_speed,Float:health;

        GetVehicleVelocity(vid,speed_x,speed_y,speed_z);
        temp_speed = floatsqroot(((speed_x*speed_x)+(speed_y*speed_y))+(speed_z*speed_z))*136.666667;
        final_speed = floatround(temp_speed,floatround_round);
        format(string,sizeof string,"Speed:  %i",final_speed);
        TextDrawSetString(td_vspeed[i],string);

        GetVehicleHealth(vid,health);
        if (max_vhealth[vid] == 0)//if its an random spawned vehicle
        {
            fuel[vid] = 300;
            GetVehicleHealth(vid,max_vhealth[vid]);
        }
        health = (((health - max_vhealth[vid]) /max_vhealth[vid]) *100)+ 100;
        format(string,sizeof string,"Health: %i",floatround(health,floatround_round));
        TextDrawSetString(td_vhealth[i],string);
    }
    return 1;
}

public timer_refuel(playerid)
{
    new vid = GetPlayerVehicleID(playerid);
    if(Engine[playerid]==0)
    {
        new veh = GetPlayerVehicleID(playerid);
        new engine,lights,alarm,doors,bonnet,boot,objective;
        GetVehicleParamsEx(veh,engine,lights,alarm,doors,bonnet,boot,objective);
        SetVehicleParamsEx(veh,VEHICLE_PARAMS_ON,lights,alarm,doors,bonnet,boot,objective);
        Engine[playerid]=1;
    }
    fuel[vid] = fuel[vid] = 300;
    isrefuelling[playerid] = 0;
    TextDrawSetString(td_fuel[playerid],"Fuel:100");
}

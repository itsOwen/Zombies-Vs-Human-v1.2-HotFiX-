@ECHO OFF
TITLE PawnCompiler
COLOR 9F
ECHO.
..\pawno\pawncc.exe "%CD%\..\gamemodes\zombie2.pwn" -i"%CD%\..\include" -(+ -;+ -r
ECHO.
ECHO Koniec kompilacji
ECHO.
PAUSE > nul